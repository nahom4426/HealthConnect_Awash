<script setup lang="js">
import Button from "@/components/Button.vue";
import ClaimDetail from "../../components/ClaimDetail.vue";
import ClaimIndividualDetailDataProvider from "../../components/ClaimIndividualDetailDataProvider.vue";
import { openModal } from "@customizer/modal-x";
import { useApiRequest } from "@/composables/useApiRequest";
import {
  claimApproved,
  claimProccessed,
  claimVerified,
} from "../../api/claimApi";
import { toasted } from "@/utils/utils";
import { useRoute } from "vue-router";

const route = useRoute();
const batchCode = route.params.batchCode;

const approveClaimReq = useApiRequest();

function approveClaim(data) {
  if (approveClaimReq.pending.value) return;
  openModal(
    "Comment",
    {
      title: "Approve Claim",
    },
    (comment) => {
      if (comment) {
        approveClaimReq.send(
          () =>
            claimApproved({
              comment,
              batchCode,
              claimUuidRequest: [{ claimUuid: data.claimUuid }],
            }),
          (res) => {
            if (res.success) {
              toasted(true, "Claim Ready for Authorization");
            }
          }
        );
      }
    }
  );
}
</script>

<template>
  <ClaimIndividualDetailDataProvider v-slot="{ pending, ...rest }">
    <ClaimDetail v-bind="rest">
      <template #claimActions="{}">
        <Button
          :pending="approveClaimReq.pending.value"
          v-if="
            rest.detail?.claimStatus == 'CHECKED' &&
            !approveClaimReq.dirty.value &&
            !approveClaimReq.error.value
          "
          @click="approveClaim(rest.detail)"
          type="primary"
        >
          Approve
        </Button>
      </template>
    </ClaimDetail>
  </ClaimIndividualDetailDataProvider>
</template>
