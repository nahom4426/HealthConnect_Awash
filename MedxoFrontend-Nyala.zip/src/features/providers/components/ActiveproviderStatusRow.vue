<script setup>
import { defineProps, onMounted, onUnmounted, computed } from 'vue';
import { storeToRefs } from 'pinia';
import { openModal } from '@customizer/modal-x';
import { useProviders } from "@/features/providers/store/providersStore";
import { useToast } from '@/toast/store/toast';
import icons from "@/utils/icons";
import { changeProviderStatus } from '../api/providerApi';

const emit = defineEmits(['row', 'remove']);

const props = defineProps({
  rowData: {
    type: Array,
    required: true
  },
  rowKeys: {
    type: Array,
    required: true
  },
  headKeys: {
    type: Array,
    required: true
  },
  cells: {
    type: [Object, Array],
    default: () => ({})
  },
  isMobile: {
    type: Boolean,
    default: false
  },
  onView: {
    type: Function,
    default: () => {}
  },
  onEdit: {
    type: Function,
    default: () => {}
  },
  onActivate: {
    type: Function,
    default: () => {}
  },
  onDeactivate: {
    type: Function,
    default: () => {}
  },
  onRowClick: {
    type: Function,
    default: () => {}
  },
  currentPage: { type: Number, default: 1 },
  perPage: { type: Number, default: 25 }
});

const { addToast } = useToast();
const providersStore = useProviders();
const { providers: storeProviders } = storeToRefs(providersStore);

// Enhanced hasAdminUser function
function hasAdminUser(row) {
  if (!row) {
    console.warn('Row is null/undefined');
    return false;
  }

  // Check both possible properties (users or userList)
  const userArray = row.users || row.userList || [];
  
  if (!Array.isArray(userArray)) {
    console.warn('User data is not an array:', userArray);
    return false;
  }

  const hasAdmin = userArray.length > 0 && userArray.some(user => user?.userUuid);
  console.log(`Admin check for ${row.providerName}:`, {
    hasUsers: userArray.length > 0,
    hasValidUser: userArray.some(user => user?.userUuid),
    result: hasAdmin
  });
  
  return hasAdmin;
}

function getStatusStyle(status) {
  const base = "inline-flex justify-center items-center min-w-[80px] px-3 py-1 rounded text-sm font-semibold";

  switch (status?.toUpperCase()) {
    case "APPROVED":
      return `${base} bg-green-100 text-green-800`;
      case "ACTIVE":
      return `${base} bg-green-100 text-green-800`;
      case "SUBMITTED":
      return `${base} bg-yellow-100 text-yellow-800`;
        // Light green for active
    case "SUSPENDED":
      return `${base} bg-red-100 text-red-800`;    // Light gray for SUSPENDED
    case "PENDING":
      return `${base} bg-yellow-100 text-yellow-800`; // Light yellow for pending
    case "ACCEPTED":
      return `${base} bg-blue-100 text-blue-800`;     // Light blue for accepted
    case "REJECTED":
      return `${base} bg-red-100 text-red-800`;       // Light red for rejected
    case "RESUBMITTED":
      return `${base} bg-purple-100 text-purple-800`;
    case "SUSPENDED":
      return `${base} bg-yellow-100 text-yellow-800`; // Light yellow for suspended
    default:
      return `${base} bg-gray-100 text-gray-800`;    // Default light gray
  }
}

function getBaseUrl() {
  return import.meta.env.VITE_API_URL ;
}

function handleImageError(event) {
  event.target.src = '/assets/placeholder-logo.png ';
}

function handleEdit(row) {
  openModal('EditProvider', { 
    providerUuid: row.providerUuid, 
    provider: row,
    onUpdated: (updatedProvider) => {
      providersStore.update(updatedProvider.providerUuid, updatedProvider);
    }
  });
}

function handleEditAdmin(row) {
  const providerName = row.providerName || '';
  const roleName = `PR_${providerName}_Manager`;
  
  // Get the first admin user if exists
  const adminUser = hasAdminUser(row) ? row.users.find(u => u.userUuid) : null;
  
  openModal('EditUser', {
    providerUuid: row.providerUuid,
    provider: row,
    user: adminUser, // Pass existing user data if available
    userUuid: adminUser?.userUuid || '', // Required for EditUser modal
    roleName: roleName,
    onUpdated: (updatedProvider) => {
      providersStore.update(updatedProvider.providerUuid, updatedProvider);
    }
  });
}

function handleAddAdmin(row) {
  const providerName = row.providerName || '';
  const roleName = `PR_${providerName}_Manager`;
  
  openModal('AddUser', {
    providerUuid: row.providerUuid,
    provider: row,
    roleName: roleName,
    onUpdated: (updatedProvider) => {
      providersStore.update(updatedProvider.providerUuid, updatedProvider);
    }
  });
}

// Dropdown functions
function toggleDropdown(event, rowId) {
  event.stopPropagation();
  closeAllDropdowns();
  const dropdown = document.getElementById(`dropdown-${rowId}`);
  if (dropdown) dropdown.classList.toggle('hidden');
}

function closeAllDropdowns() {
  document.querySelectorAll('.dropdown-menu').forEach(el => {
    el.classList.add('hidden');
  });
}

// Wrapper functions with dropdown close
function handleEditWithClose(row) {
  closeAllDropdowns();
  handleEdit(row);
}

function handleAddAdminWithClose(row) {
  closeAllDropdowns();
  handleAddAdmin(row);
}

function handleEditAdminWithClose(row) {
  closeAllDropdowns();
  handleEditAdmin(row);
}

async function handleActivateWithClose(providerId) {
  closeAllDropdowns();
  try {
    const response = await changeProviderStatus(providerId, 'ACTIVE');
    if (response.success) {
      addToast({
        type: 'success',
        title: 'Status Updated',
        message: 'Provider has been activated successfully'
      });
      providersStore.update(providerId, { status: 'ACTIVE' });
    } else {
      throw new Error(response.error || 'Failed to activate provider');
    }
  } catch (error) {
    addToast({
      type: 'error',
      title: 'Activation Failed',
      message: error.message || 'An error occurred while activating the provider'
    });
  }
}

async function handleDeactivateWithClose(providerId) {
  closeAllDropdowns();
  try {
    const response = await changeProviderStatus(providerId, 'SUSPENDED');
    if (response.success) {
      addToast({
        type: 'success',
        title: 'Status Updated',
        message: 'Provider has been deactivated successfully'
      });
      providersStore.update(providerId, { status: 'SUSPENDED' });
    } else {
      throw new Error(response.error || 'Failed to deactivate provider');
    }
  } catch (error) {
    addToast({
      type: 'error',
      title: 'Deactivation Failed',
      message: error.message || 'An error occurred while deactivating the provider'
    });
  }
}

onMounted(() => {
  window.addEventListener('click', closeAllDropdowns);
});

onUnmounted(() => {
  window.removeEventListener('click', closeAllDropdowns);
});
</script>

<template>
  <tr 
    v-for="(row, idx) in rowData" 
    :key="idx"
    @click.self="onRowClick(row)" 
    class="bg-white border-b transition-colors duration-150 ease-in-out hover:bg-gray-50" 
  >  
    <td class="p-4 font-medium text-gray-500">{{ (props.currentPage - 1) * props.perPage + idx + 1 }}</td>  

    <!-- Debug row for specific provider -->
    <!-- <td v-if="row.providerName === 'Addis Hiwot'" class="p-2 text-xs bg-yellow-50 debug-info">
      <div class="font-bold">Debug Info for {{ row.providerName }}:</div>
      <div>Has users property: {{ 'users' in row }}</div>
      <div>Users is array: {{ Array.isArray(row.users) }}</div>
      <div>User count: {{ row.users?.length || 0 }}</div>
      <div>First user UUID: {{ row.users?.[0]?.userUuid || 'none' }}</div>
      <div>Store has users: {{ 
        storeProviders.find(p => p.providerUuid === row.providerUuid)?.users?.length > 0 
      }}</div>
    </td> -->

    <!-- Provider Logo Column -->
    <td class="p-3 py-4" v-for="key in rowKeys" :key="key">  
      <div v-if="key === 'status'" class="truncate">  
        <span 
          class="px-2.5 py-1 text-xs font-medium rounded-full"
          :class="getStatusStyle(row.status)"
        >
          {{ row.status }}
        </span>
      </div>
      <div v-else-if="key === 'totalContracts'" class="truncate">  
        <span class="text-gray-700">
          {{ row.totalContracts || 0 }}
        </span>
      </div>
      
      <div v-else-if="key === 'providerName'" class="flex gap-2.5 items-center text-gray-700">
        <div class="flex justify-center items-center">
          <img 
            v-if="row.logoBase64" 
            :src="row.logoBase64" 
            alt="Provider Logo" 
            class="object-contain w-10 h-10 rounded-full border border-gray-200"
          />
          <img 
            v-else-if="row.logoUrl" 
            :src="row.logoUrl" 
            alt="Provider Logo" 
            class="object-contain w-10 h-10 rounded-full border border-gray-200"
            @error="handleImageError"
          />
          <img 
            v-else-if="row.logoPath" 
            :src="`${getBaseUrl()}/provider/logo/${row.logoPath}`" 
            alt="Provider Logo" 
            class="object-contain w-10 h-10 rounded-full border border-gray-200"
            @error="handleImageError"
          />
          <div v-else class="flex justify-center items-center w-10 h-10 text-center bg-gray-200 rounded-full">
            <span class="text-xs text-gray-500">No Logo</span>
          </div>
        </div>
        <div>{{ row.providerName }}</div>
      </div>
      
      <span v-else class="text-gray-700">
        {{ row[key] }}
      </span>
    </td>  

    <!-- Actions Column -->
    <td class="p-3" v-if="headKeys.includes('Actions') || headKeys.includes('actions')">
  <div class="flex flex-wrap gap-2 justify-start items-center">

    <!-- ✅ Activate -->
    <button
      v-if="row.status === 'SUSPENDED' || row.status === 'Suspended'"
      @click.stop="handleActivateWithClose(row.providerUuid || row.id)"
      class="flex gap-2 items-center px-3 py-1.5 text-sm font-semibold text-green-600 bg-green-50 rounded-xl border border-green-200 transition-all duration-200 hover:bg-green-100 hover:shadow-sm"
    >
      <i v-html="icons.activate" class="text-green-500" />
      <span>Activate</span>
    </button>

    <!-- ⛔ Deactivate -->
    <button
      v-if="row.status === 'ACTIVE' || row.status === 'Active'"
      @click.stop="handleDeactivateWithClose(row.providerUuid || row.id)"
      class="flex gap-2 items-center px-3 py-1.5 text-sm font-semibold text-red-600 bg-red-50 rounded-xl border border-red-200 transition-all duration-200 hover:bg-red-100 hover:shadow-sm"
    >
      <i v-html="icons.deactivate" class="text-red-500" />
      <span>Deactivate</span>
    </button>

    <!-- ✏️ Edit -->
    <!-- <button
      @click.stop="handleEditWithClose(row)"
      class="flex gap-2 items-center px-3 py-1.5 text-sm font-semibold text-blue-600 bg-blue-50 rounded-xl border border-blue-200 transition-all duration-200 hover:bg-blue-100 hover:shadow-sm"
    >
      <i v-html="icons.edit" class="text-blue-500" />
      <span>Edit</span>
    </button> -->

    <!-- 👁️ Detail (optional) -->
    <!--
    <button
      @click.stop="handleViewWithClose(row.providerUuid || row.id)"
      class="flex gap-2 items-center px-3 py-1.5 text-sm font-semibold text-indigo-600 bg-indigo-50 rounded-xl border border-indigo-200 transition-all duration-200 hover:bg-indigo-100 hover:shadow-sm"
    >
      <i v-html="icons.details" class="text-indigo-500" />
      <span>Detail</span>
    </button>
    -->
  </div>
</td>

  </tr>
</template>

<style scoped>
.dropdown-container {
  min-width: 80px;
}

.dropdown-menu {
  min-width: 150%;
  transition: all 0.2s ease-out;
  transform-origin: top right;
}

.dropdown-menu.hidden {
  opacity: 0;
  transform: scale(0.95);
  pointer-events: none;
}

.dropdown-menu:not(.hidden) {
  opacity: 1;
  transform: scale(1);
}

.debug-info {
  font-family: monospace;
  white-space: pre;
}
</style>