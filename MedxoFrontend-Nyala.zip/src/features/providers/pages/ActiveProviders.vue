<script setup>
import { ref, defineEmits } from "vue";
import { useRouter } from "vue-router";
import Table from "@/components/Table.vue";
import DefaultPage from "@/components/DefaultPage.vue";
import ActiveProvidersDataProvider from "../components/ActiveProviderSDataProvider.vue";
import { useApiRequest } from "@/composables/useApiRequest";
import ActiveproviderStatusRow from "../components/ActiveproviderStatusRow.vue";
import { openModal } from "@customizer/modal-x";
import { useProviders } from "../store/providersStore";
import icons from "@/utils/icons";

const emit = defineEmits(["navigate"]);
const router = useRouter();
const dataProvider = ref();
const providersStore = useProviders();
const statusReq = useApiRequest();
const deleteReq = useApiRequest();

function refreshData() {
  console.log("Refreshing provider data");
  if (dataProvider.value) {
    dataProvider.value.refresh();
  }
}

function handlePageChange(page) {
  if (dataProvider.value) {
    dataProvider.value.setPage(page);
  }
}

function handleLimitChange(limit) {
  if (dataProvider.value) {
    dataProvider.value.setLimit(limit);
  }
}

function viewDetails(id) {
  router.push(`/providers/${id}`);
}
</script>

<template>
  <DefaultPage placeholder="Search Active Providers">
    <!-- <template #filter>
      <button
        class="flex gap-2 justify-center items-center px-6 py-4 bg-gray-100 rounded-md text-primary"
      >
        <i v-html="icons.filter"></i>
        <p class="text-base">Filters</p>
      </button>
    </template>

    <template #add-action>
      <button
        @click.prevent="openModal('AddProvider')"
        class="flex gap-2 justify-center items-center px-6 py-4 text-white rounded-md bg-primary"
      >
        <i v-html="icons.plus_circle"></i>
        <p class="text-base">Add Provider</p>
      </button>
    </template> -->

    <template #default="{ search }">
      <ActiveProvidersDataProvider
        ref="dataProvider"
        :search="search"
        v-slot="{ providers, pending }"
      >
        <Table
          :pending="pending"
          :virtual="true"
          :itemKey="'providerUuid'"
          :virtualHeight="600"
          :virtualItemSize="64"
          :headers="{
            head: [
              'Provider Name',
              'Contact Person',
              'Contact',
              'Category',
          
              'Status',
              'Actions',
            ],
            row: [
              'providerName',
              'email',
              'telephone',
              'category',
           
              'status',
            ],
          }"
          :rows="providers"
          :rowCom="ActiveproviderStatusRow"
          :pagination="{
            onPageChange: handlePageChange,
            onLimitChange: handleLimitChange,
          }"
        >
          <template #row>
            <ActiveproviderStatusRow
              :rowData="providers"
              :rowKeys="[
                'providerName',
                'email',
                'telephone',
                'category',
    
                'status',
              ]"
              :headKeys="[
                '',
                'Provider Name',
                'Email',
                'Telephone',
                'Category',
   
                'Status',
                'Actions',
              ]"
              :onView="viewDetails"
              :onRowClick="(row) => {}"
            /> 
          </template>
        </Table>
      </ActiveProvidersDataProvider>
    </template>
  </DefaultPage>
</template>
